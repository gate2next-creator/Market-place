import SwiftUI

struct VerifyView: View {
    var body: some View {
        VStack {
            Text("Doğrula")
                .font(.largeTitle)
                .bold()
            Spacer()
        }
        .padding()
    }
}

#Preview {
    VerifyView()
}
