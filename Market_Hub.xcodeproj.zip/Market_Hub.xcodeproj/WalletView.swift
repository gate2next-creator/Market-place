import SwiftUI

struct WalletView: View {
    var body: some View {
        VStack {
            Text("Cüzdan")
                .font(.largeTitle)
                .bold()
            Spacer()
        }
        .padding()
    }
}

#Preview {
    WalletView()
}
