import SwiftUI

struct MainTabView: View {
    var body: some View {
        TabView {
            DiscoverView()
                .tabItem {
                    Label("Keşfet", systemImage: "map")
                }
            WalletView()
                .tabItem {
                    Label("Cüzdan", systemImage: "wallet.pass")
                }
            BusinessDetailView()
                .tabItem {
                    Label("İşletme", systemImage: "building.2")
                }
            RegisterView()
                .tabItem {
                    Label("Kayıt", systemImage: "person.crop.circle.badge.plus")
                }
            ProfileView()
                .tabItem {
                    Label("Profil", systemImage: "person.circle")
                }
            VerifyView()
                .tabItem {
                    Label("Doğrula", systemImage: "qrcode")
                }
        }
    }
}

#Preview {
    MainTabView()
}
