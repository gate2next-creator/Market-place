import SwiftUI

struct RegisterView: View {
    var body: some View {
        VStack {
            Text("Kayıt")
                .font(.largeTitle)
                .bold()
            Spacer()
        }
        .padding()
    }
}

#Preview {
    RegisterView()
}
