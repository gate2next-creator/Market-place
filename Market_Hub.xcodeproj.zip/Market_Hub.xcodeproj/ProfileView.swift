import SwiftUI

struct ProfileView: View {
    var body: some View {
        VStack {
            Text("Profil")
                .font(.largeTitle)
                .bold()
            Spacer()
        }
        .padding()
    }
}

#Preview {
    ProfileView()
}
