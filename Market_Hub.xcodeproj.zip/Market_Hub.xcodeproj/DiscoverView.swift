import SwiftUI

struct DiscoverView: View {
    var body: some View {
        VStack {
            Text("Keşfet")
                .font(.largeTitle)
                .bold()
            Spacer()
        }
        .padding()
    }
}

#Preview {
    DiscoverView()
}
