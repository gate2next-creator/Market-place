import SwiftUI

struct BusinessDetailView: View {
    var body: some View {
        VStack {
            Text("İşletme")
                .font(.largeTitle)
                .bold()
            Spacer()
        }
        .padding()
    }
}

#Preview {
    BusinessDetailView()
}
